package com.example.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmpServiceImpl;

@RestController
@RequestMapping("/emp")
public class EmpController {
	
	@Autowired
	private EmpServiceImpl empServiceImpl;
	
	@PostMapping
	public void add(@RequestBody Employee employee) {
		empServiceImpl.addEmployee(employee);
	}
	
	@GetMapping("/findAll")
	public List<Employee> getAllEmployee(@PathVariable Employee employee){
		return empServiceImpl.findAllEmployee(employee);
	}
	
	@GetMapping("/{id}")
	public Employee getEmployeeById(@PathVariable long id) {
		return empServiceImpl.findAllEmployeeById(id);
	}
	
	@DeleteMapping("/delete")
	public void delete() {
		empServiceImpl.deleteAllData();
	}	
}
