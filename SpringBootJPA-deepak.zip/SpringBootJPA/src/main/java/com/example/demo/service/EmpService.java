package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Employee;

public interface EmpService {

	List<Employee> findAllEmployee(Employee employee);
	Employee findAllEmployeeById(long id);
	void deleteAllData();
	Employee addEmployee(Employee employee);
	}
