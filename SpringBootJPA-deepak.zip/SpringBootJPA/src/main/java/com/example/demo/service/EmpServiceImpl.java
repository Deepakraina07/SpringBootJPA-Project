package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmpServiceImpl implements EmpService {
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee addEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public void deleteAllData() {
		employeeRepository.deleteAll();
	}

	public List<Employee> findAllEmployee(Employee employee) {

		return employeeRepository.findAll();
	}

	@Override
	public Employee findAllEmployeeById(long id) {
		Optional<Employee> opt = employeeRepository.findById(id);
		if (opt.isPresent())
			return opt.get();
		else
			return null;
	}

}
